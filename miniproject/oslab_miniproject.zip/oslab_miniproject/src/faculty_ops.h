// faculty_ops.h
#ifndef FACULTY_OPS_H
#define FACULTY_OPS_H

// Handles faculty menu choice
void process_faculty(int client_sock, int choice, const char *username);

#endif
