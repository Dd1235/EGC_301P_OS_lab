// student_ops.h
#ifndef STUDENT_OPS_H
#define STUDENT_OPS_H

// Dispatches the selected student operation
void process_student(int client_sock, int choice, const char *username);

#endif
