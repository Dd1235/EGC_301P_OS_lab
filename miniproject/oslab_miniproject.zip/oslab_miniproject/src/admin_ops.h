// admin_ops.h
#ifndef ADMIN_OPS_H
#define ADMIN_OPS_H

// Processes admin menu choices
void process_admin(int client_sock, int choice);

#endif
